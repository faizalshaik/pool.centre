<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Africa/Lagos');
		
		$this->load->model('Admin_model');
		$this->load->model('Base_model');
		$this->load->model('User_model');
		$this->load->model('Game_model');
		$this->load->model('Option_model');
		$this->load->model('UserOption_model');
		$this->load->model('Setting_model');
		$this->load->model('Terminal_model');
		$this->load->model('Week_model');
		$this->load->model('Prize_model');	
		$this->load->model('FundRequest_model');
		$this->load->model('Bet_model');
		$this->load->model('Summary_model');
		$this->load->model('DeleteRequest_model');
	}

	public function reply($status, $message, $data)
	{
		$result = array('status'=>$status, 'message'=>$message, 'data'=>$data);
		echo json_encode($result);
	}

	private function calc_line($unders, $nGame)
	{
		$line = 0;
		foreach($unders as $under)
		{
			$val = 	$nGame;
			$div = 1;
			for($i=2; $i<=$under; $i++)
			{
				$div *= $i;
				$val *= ($nGame - $i +1);
			}
			$line += ($val/$div);
		}
		return $line;
	}
	
	private function calcLine($bet)
	{
		$line = 1;
		if ($bet['type'] == "Nap/Perm") {
			$line = $this->calc_line($bet['under'], count($bet['gamelist']));
		}
		else if ($bet['type'] == "Group") {
			foreach($bet['gamelist'] as $grp)
			{
				$line *= $this->calc_line($grp['under'], count($grp['list']));
			}
		}
		return $line;
	}


	private function calcSummary($userId, $agent_id, $option, $commission, $week_no, $tag) 
	{
		$summaryId =$userId."_".$tag.'_'.$option.'_'.$week_no;
		$sales = 0;
		$win = 0;
		$bets = null;
		$bets = $this->Bet_model->getDatas(array('user_id'=>$userId, 'option_id'=>$option, 'week'=>$week_no, 'tag'=>$tag, 'status'=>1));

		if(count($bets)==0) return;

		$terminalIds = array();
		foreach($bets as $bet)
		{
			$sales += $bet->stake_amount;
			$win += $bet->won_amount;
			$terminalIds[$bet->terminal_id] = $bet->terminal_id;
		}

		$terminals = array();
		foreach($terminalIds as $key=>$val) $terminals[] = $key;		

		$data = array('summary_id'=>$summaryId, 'user_id'=>$userId, 'tag'=>$tag, 'agent_id'=>$agent_id, 
			'option_id'=>$option, 'commission'=>$commission, 'week_no'=>$week_no, 
			'sales'=>$sales, 'win'=>$win, 'payable'=>$sales * $commission/100, 'terminals'=>join(',', $terminals) );

		$row = $this->Summary_model->getRow(array('summary_id'=>$summaryId));

		if($row)
		{
			$this->Summary_model->updateData(array('Id'=>$row->Id),$data);
		}
		else
		{
			$this->Summary_model->insertData($data);
		}

	}

	private function classify_scores($games, $scores)
	{
		$scored = array();
		$unscored = array();		
		foreach($games as $game)
		{
			$exist = false;
			foreach($scores as $score)
			{
				if($game == $score)
				{
					$exist = true; break;
				}
			}
			if($exist) $scored[]=$game;
			else $unscored[]=$game;
		}
		return array('good'=>$scored, 'bad'=>$unscored);
	}
	private function getPrizeValue($prizes, $underId, $optionId)
	{
		foreach($prizes as $prize)		
		{
			if($prize->under != $underId) continue;
			if($prize->option_id != $optionId) continue;
			return $prize->prize;
		}
		return 0;
	}
	public function apply_game_result()
	{
		$this->logonCheck();
		$options = $this->Option_model->getDatas(null);
		$curWeekNo = $this->Setting_model->getCurrentWeekNo();
		$prizes = $this->Prize_model->getDatas(array('week_no'=>$curWeekNo));
		$scores = $this->Game_model->getDatas(array('status'=>1, 'week_no'=>$curWeekNo, 'checked'=>1));
		$bets = $this->Bet_model->getBets(array('status'=>1, 'week'=>$curWeekNo));

		$scorelists = array();
		foreach($scores as $game) $scorelists[]=$game->game_no;

		foreach($bets as $bet)
		{
			//classify scoredlist
			$scoreList = null;
			$unscoreList = null;
			if($bet['type']=="Nap/Perm")
			{
				$classifiedData = $this->classify_scores($bet['gamelist'], $scorelists);
				$scoreList = $classifiedData['good'];
				$unscoreList = $classifiedData['bad'];
			}
			else if($bet['type']=="Group")
			{
				$scoreList = array();
				$unscoreList = array();	
				foreach($bet['gamelist'] as $grp)
				{
					$classifiedData = $this->classify_scores($grp['list'], $scorelists);
					$scoreList[] = array('under'=>$grp['under'], 'list'=>$classifiedData['good']);
					$unscoreList[] = array('under'=>$grp['under'], 'list'=>$classifiedData['bad']);
				}
			}

			$lines = $this->calcLine($bet);			
			$apl = $bet['stake_amount']/$lines;
			$won_amount = 0;
			$win_result = "Lost";
			if($bet['type']=="Nap/Perm")
			{
				foreach($bet['under'] as $under)
				{
					$winLine = $this->calc_line(array($under), count($scoreList));
					$prizeVal = $this->getPrizeValue($prizes, $under, $bet['option_id']);
					$won_amount +=($apl * $winLine * $prizeVal);
				}	
			}
			else 
			{
				$winLine = 1;
				for($i=0; $i< count($bet['gamelist']); $i++)
				{
					$grp = $bet['gamelist'][$i];
					$nScored = count($scoreList[$i]['list']);
					if($nScored < $grp['under'][0])
					{
						$winLine = 0;
						break;
					}
					$winLine *= $this->calc_line($grp['under'], $nScored);
				}
				$prizeVal = $this->getPrizeValue($prizes, $under, $bet['option_id']);
				$won_amount =($apl * $winLine * $prizeVal);
			}


			if($won_amount>0)
				$win_result = "Win";


			$this->Bet_model->updateData(array('Id'=>$bet['Id']), 
				array('score_list'=>json_encode($scoreList), 
						'unscore_list'=>json_encode($unscoreList),
						'apl'=>$apl,
						'win_result'=>$win_result,
						'won_amount'=>$won_amount
					));
			// $commission = 0;
			// if($option!=null) $commission = $option->commision;

			// if($bet['user_id']>0)
			// 	$this->calcTerminalSummary($bet['user_id'], $bet['agent_id'], $option->Id, $commission, $curWeekNo, false);
			// else 
			// 	$this->calcTerminalSummary($bet['terminal_id'], $bet['agent_id'], $option->Id, $commission, $curWeekNo, true);			
		}

		$users = $this->User_model->getDatas(array('status'=>1, 'type'=>'player'));
		foreach($users as $usr)
		{
			foreach($options as $opt)
			{
				for($tag=1; $tag <=5; $tag++)
					$this->calcSummary($usr->Id,  $usr->agent_id, $opt->Id,$opt->commision, $curWeekNo, $tag);
			}
		}
		$this->reply(200, "ok", null);
	}

	private function checkMissedGames($gamelists, $bet)
	{
		$missed = array();		
		if($bet['type']=='Group')
		{
			foreach($bet['gamelist'] as $grp)
			{
				foreach($grp['list'] as $gameNo)
				{
					$bExist = false;
					foreach($gamelists as $game)
					{
						if($game->game_no==$gameNo)
						{
							$bExist = true;
							break;
						}
					}
					if($bExist==false) $missed[]=$gameNo;
				}
			}
		}
		else
		{
			foreach($bet['gamelist'] as $gameNo)
			{
				$bExist = false;
				foreach($gamelists as $game)
				{
					if($game->game_no==$gameNo)
					{
						$bExist = true;
						break;
					}
				}
				if($bExist==false) $missed[]=$gameNo;
			}
		}
		return $missed;
	}	
	private function void_bet_for_user($bet, $betId)
	{
		$betId = $bet['Id'];				
		$user = $this->User_model->getRow(array('Id'=>$bet['user_id']));
		if($user ==null)
			return $this->reply(-1, "user dose not exist", null);

		$week = $this->Week_model->getRow(array('week_no'=>$bet['week']));
		if($week==null)
			return $this->reply(-1, "week dose not exist", null);

		$curDate = new DateTime();
		if($curDate->format('Y-m-d H:i:s') > $week->close_at)
			return $this->reply(1004, "bet does not change in past week", null);

		$curDate->sub(new DateInterval('PT'.$week->void_bet.'H'));
		if($curDate->format('Y-m-d H:i:s') > $bet['bet_time'])
			return $this->reply(1003, "void time passed", null);

		$gamelists = $this->Game_model->getDatas(array('week_no'=>$week->week_no, 'status'=>1));
		if($gamelists==null)
			return $this->reply(-1, "game does not exist", null);

		$missed = $this->checkMissedGames($gamelists, $bet);
		if(count($missed)>0)
			return $this->reply(1003, "void failed", null);

		//save deelte request
		$row = $this->DeleteRequest_model->getRow(array('bet_id'=>$betId));
		if($row!=null)
			return $this->reply(1003, "already requested", null);

		$this->DeleteRequest_model->insertData(array('bet_id'=>$betId, 'user_id'=>$user->Id, 'agent_id'=>$user->agent_id));

		//update bet status
		$this->Bet_model->updateData(array('Id'=>$betId), array('status'=>2));
		
		$commision = 0 ;
		$opt = 	$this->PlayerOption_model->getRow(array('player_id'=>$user->Id, 'option_id'=>$bet['option_id']));
		if($opt!=null) $commision = $opt->commision;	

		//return $this->reply(1003, "kkk", null);															

		$this->calcTerminalSummary($user->Id, $user->agent_id, $bet['option_id'], $commision, $bet['week'], false);
		return $this->reply(200, "success", null);
	}	

	public function void_bet()
	{
		$this->logonCheck();
		$id = $this->input->post('Id');	
		$bets = $this->Bet_model->getBets(array('Id'=>$id));
		if(count($bets)==0)
			return $this->reply(-1, "bet_id dose not exist", null);
		$bet = $bets[0];
		$betId = $bet['Id'];
				
		if($bet['terminal_id'] ==0 && $bet['user_id'] > 0)
		{
			$this->void_bet_for_user($bet, $betId);
			return;
		}

		$terminal = $this->Terminal_model->getRow(array('Id'=>$bet['terminal_id']));
		if($terminal ==null)
			return $this->reply(-1, "terminal dose not exist", null);

		$week = $this->Week_model->getRow(array('week_no'=>$bet['week']));
		if($week==null)
			return $this->reply(-1, "week dose not exist", null);

		$curDate = new DateTime();
		if($curDate->format('Y-m-d H:i:s') > $week->close_at)
			return $this->reply(1004, "bet does not change in past week", null);

		$curDate->sub(new DateInterval('PT'.$week->void_bet.'H'));
		if($curDate->format('Y-m-d H:i:s') > $bet['bet_time'])
			return $this->reply(1003, "void time passed", null);

		$gamelists = $this->Game_model->getDatas(array('week_no'=>$week->week_no, 'status'=>1));
		if($gamelists==null)
			return $this->reply(-1, "game does not exist", null);

		$missed = $this->checkMissedGames($gamelists, $bet);
		if(count($missed)>0)
			return $this->reply(1003, "void failed", null);

		//save deelte request
		$row = $this->DeleteRequest_model->getRow(array('bet_id'=>$betId));
		if($row!=null)
			return $this->reply(1003, "already requested", null);

		$this->DeleteRequest_model->insertData(array('bet_id'=>$betId, 'terminal_id'=>$terminal->Id, 'agent_id'=>$terminal->agent_id));

		//update bet status
		$this->Bet_model->updateData(array('Id'=>$betId), array('status'=>2));
		
		$commision = 0 ;
		$opt = 	$this->TerminalOption_model->getRow(array('terminal_id'=>$terminal->Id, 'option_id'=>$bet['option_id']));
		if($opt!=null) $commision = $opt->commision;	

		//return $this->reply(1003, "kkk", null);

		$this->calcTerminalSummary($terminal->Id, $terminal->agent_id, $bet['option_id'], $commision, $bet['week'], true);
		return $this->reply(200, "success", null);
	}	
	
	private function unVoid_bet_for_user($bet, $betId)
	{
		$betId = $bet['Id'];				
		$user = $this->User_model->getRow(array('Id'=>$bet['user_id']));
		if($user ==null)
			return $this->reply(-1, "user dose not exist", null);

		$week = $this->Week_model->getRow(array('week_no'=>$bet['week']));
		if($week==null)
			return $this->reply(-1, "week dose not exist", null);

		$curDate = new DateTime();
		if($curDate->format('Y-m-d H:i:s') > $week->close_at)
			return $this->reply(1004, "bet does not change in past week", null);

		$curDate->sub(new DateInterval('PT'.$week->void_bet.'H'));
		if($curDate->format('Y-m-d H:i:s') > $bet['bet_time'])
			return $this->reply(1003, "void time passed", null);

		$gamelists = $this->Game_model->getDatas(array('week_no'=>$week->week_no, 'status'=>1));
		if($gamelists==null)
			return $this->reply(-1, "game does not exist", null);

		$missed = $this->checkMissedGames($gamelists, $bet);
		if(count($missed)>0)
			return $this->reply(1003, "void failed", null);

		$this->DeleteRequest_model->deleteRow(array('bet_id'=>$betId));

		//update bet status
		$this->Bet_model->updateData(array('Id'=>$betId), array('status'=>1));
		
		$commision = 0 ;
		$opt = 	$this->PlayerOption_model->getRow(array('player_id'=>$user->Id, 'option_id'=>$bet['option_id']));
		if($opt!=null) $commision = $opt->commision;	

		//return $this->reply(1003, "kkk", null);															

		$this->calcTerminalSummary($user->Id, $user->agent_id, $bet['option_id'], $commision, $bet['week'], false);
		return $this->reply(200, "success", null);
	}	


	public function unVoid_bet()
	{
		$this->logonCheck();
		$id = $this->input->post('Id');	
		$bets = $this->Bet_model->getBets(array('Id'=>$id));
		if(count($bets)==0)
			return $this->reply(-1, "bet_id dose not exist", null);
		$bet = $bets[0];
		$betId = $bet['Id'];
				
		if($bet['terminal_id'] ==0 && $bet['user_id'] > 0)
		{
			$this->unVoid_bet_for_user($bet, $betId);
			return;
		}

		$terminal = $this->Terminal_model->getRow(array('Id'=>$bet['terminal_id']));
		if($terminal ==null)
			return $this->reply(-1, "terminal dose not exist", null);

		$week = $this->Week_model->getRow(array('week_no'=>$bet['week']));
		if($week==null)
			return $this->reply(-1, "week dose not exist", null);

		$curDate = new DateTime();
		if($curDate->format('Y-m-d H:i:s') > $week->close_at)
			return $this->reply(1004, "bet does not change in past week", null);

		$curDate->sub(new DateInterval('PT'.$week->void_bet.'H'));
		if($curDate->format('Y-m-d H:i:s') > $bet['bet_time'])
			return $this->reply(1003, "void time passed", null);

		$gamelists = $this->Game_model->getDatas(array('week_no'=>$week->week_no, 'status'=>1));
		if($gamelists==null)
			return $this->reply(-1, "game does not exist", null);

		$missed = $this->checkMissedGames($gamelists, $bet);
		if(count($missed)>0)
			return $this->reply(1003, "void failed", null);

		$this->DeleteRequest_model->deleteRow(array('bet_id'=>$betId));

		//update bet status
		$this->Bet_model->updateData(array('Id'=>$betId), array('status'=>1));
		
		$commision = 0 ;
		$opt = 	$this->TerminalOption_model->getRow(array('terminal_id'=>$terminal->Id, 'option_id'=>$bet['option_id']));
		if($opt!=null) $commision = $opt->commision;	

		//return $this->reply(1003, "kkk", null);

		$this->calcTerminalSummary($terminal->Id, $terminal->agent_id, $bet['option_id'], $commision, $bet['week'], true);
		return $this->reply(200, "success", null);
	}	

}