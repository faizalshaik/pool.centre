    <footer class="footer text-right">
        © 2019. All rights reserved.
    </footer>  
    </div> <!-- content-page -->
</div>
<!-- END wrapper -->
<script src="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweet-alert.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/switchery/js/switchery.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/multiselect/js/jquery.multi-select.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/jquery-quicksearch/jquery.quicksearch.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/select2/js/select2.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-select/js/bootstrap-select.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js'); ?>" type="text/javascript"></script>

<script src="<?php echo base_url('assets/js/jquery.core.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.app.js'); ?>"></script>

<script>
    var resizefunc = [];
    //Bootstrap-TouchSpin
    $(".vertical-spin").TouchSpin({
        verticalbuttons: true,
        verticalupclass: 'ion-plus-round',
        verticaldownclass: 'ion-minus-round'
    });    
</script>



</body>

</html>